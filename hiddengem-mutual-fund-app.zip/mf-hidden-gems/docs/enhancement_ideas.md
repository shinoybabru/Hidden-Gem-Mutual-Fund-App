# Enhancement ideas

Ranked roughly by effort-to-impact for a resume/portfolio project. Pick 2-3
rather than all of them — a polished subset beats a half-finished pile of
features.

## High impact, low effort
- **Backtest the model itself.** Score funds using only data available 12
  months ago, then check whether the flagged "hidden gems" actually
  outperformed the category average since. This single chart ("Did our
  Hidden Gem picks from a year ago beat the category average?") is the
  single most convincing thing you can put on a resume — it proves the
  model isn't just a plausible-looking story.
- **Real NAV data.** Swap the synthetic NAV generator for AMFI's free
  `NAVAll.txt` feed or `mfapi.in` — no API key needed, and it instantly
  makes the project "real" to anyone reviewing it.
- **A short model card** (`docs/MODEL_CARD.md`) — what the score does and
  doesn't mean, its known limitations (survivorship bias, news-source
  coverage gaps), and what "hidden gem" is *not* claiming (it is not a buy
  recommendation). Recruiters and interviewers notice this kind of rigor.

## Medium effort
- **Real news + FinBERT sentiment**, using the template already in
  `news/real_news_ingestion_TEMPLATE.py`. FinBERT specifically (vs. generic
  sentiment) is worth naming on a resume — it signals you know
  finance-domain NLP exists and chose it deliberately.
- **A "why NOT a hidden gem" explanation** for funds that scored close to
  the threshold but didn't cross it — currently only flagged funds get a
  tailored explanation. Symmetry here makes the model feel more honest.
  Also worth adding: what would need to change (e.g. "AUM growth would
  need to reach the 65th percentile") for a near-miss fund to qualify —
  this turns the score from a verdict into an actionable answer.
- **SIP calculator inside the fund detail panel** — let a user enter a
  monthly SIP amount and horizon, and show the projected corpus using the
  fund's model-implied CAGR, not just a lump sum.
- **Category rotation view** — a small multiples chart showing which fund
  categories (Small Cap, Sectoral, Flexi Cap...) are producing the most
  Hidden Gem flags over time. This surfaces a "where's the smart money
  quietly heading" narrative on top of individual fund picks.

## Bigger lifts, but high resume value
- **Deploy the model as a live API** (FastAPI) that recomputes scores
  daily and serves them to the dashboard via `fetch()` instead of embedded
  JSON — turns this from a static demo into a real deployed service, and
  gives you a legitimate "deployed with FastAPI + cron" line on a resume.
- **Explainability with SHAP.** Replace the current rule-based explanation
  text with SHAP values from a trained gradient-boosted model — lets you
  say "used SHAP for model explainability" rather than "wrote if/else
  explanation logic," which reads as materially more advanced.
- **Portfolio-level view** — let a user pick 3-5 funds and see combined
  risk/return, overlap in underlying holdings, and category
  diversification, rather than only fund-by-fund analysis.
- **A/B the scoring weights.** Right now the four sub-scores are blended
  with fixed weights (0.32/0.28/0.25/0.15). Learning these weights instead
  — e.g. via a logistic regression trained to predict "did this fund cross
  ₹20,000cr AUM within 3 years of being flagged" on historical data — is a
  natural next step and gives you a genuine supervised-learning story
  instead of a hand-tuned heuristic.

## Presentation polish
- Record a 60-90 second screen capture of clicking through the dashboard
  and pin it to the top of the README (GitHub renders `.gif`/`.mp4`
  previews inline) — most reviewers won't clone a repo and run Python, but
  they will watch a 60-second clip.
- Deploy `dashboard/index.html` to GitHub Pages (free, one settings toggle)
  so the live link works without anyone downloading anything.
