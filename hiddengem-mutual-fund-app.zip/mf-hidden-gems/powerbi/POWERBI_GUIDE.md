# Power BI Build Guide — HiddenGem

Power BI Desktop (.pbix) is a binary file that can't be generated from code, so
this guide gives you everything to build it yourself in ~30–45 minutes:
data model, relationships, every DAX measure, and page-by-page layout. The
`dashboard/index.html` in this repo is a pixel-level preview of exactly what
you're aiming for, so build visuals to match it.

## 1. Get data

Import these into Power BI (**Get Data → Text/CSV**, or connect directly to
`data/hiddengem.db` via an ODBC/SQLite connector):

| Table | Source |
|---|---|
| `fund_scores_export.csv` | this folder — the flat, model-scored table |
| `dim_fund`, `dim_amc`, `dim_category`, `dim_date`, `fact_nav_history`, `fact_news_sentiment` | `data/hiddengem.db` (or re-run schema.sql against Postgres and connect live) |

For a **fast build**, just import `fund_scores_export.csv` as a single table —
it already has AMC-less category/risk fields joined in and will power every
visual described below. For a **resume-grade build**, import the full star
schema from `hiddengem.db` and build real relationships (this is what shows
strong data modeling skill to a recruiter).

## 2. Data model (star schema)

```
        dim_amc ─┐
                  ├─→ dim_fund ─┬─→ fact_nav_history ─→ dim_date
        dim_category ─┘         ├─→ fact_news_sentiment ─→ dim_date
                                 └─→ fact_fund_scores ─→ dim_date
```

- All fact-to-dim relationships: **one-to-many**, single direction, from dim → fact.
- Mark `dim_date` as a **Date Table** (Modeling → Mark as Date Table).
- Hide foreign key columns in fact tables after relationships are set (cleans up the field list).

## 3. Core DAX measures

Paste these into a new measure table called `_Measures`:

```DAX
Total AUM (Cr) = SUM(dim_fund[current_aum_cr])

Avg Hidden Gem Score = AVERAGE(fact_fund_scores[hidden_gem_score])

Hidden Gem Count =
CALCULATE(
    DISTINCTCOUNT(fact_fund_scores[fund_id]),
    fact_fund_scores[hidden_gem_flag] = TRUE
)

Avg Holding Period (Months) = AVERAGE(dim_fund[avg_holding_period_months])

YoY AUM Growth % =
DIVIDE(
    SUM(dim_fund[current_aum_cr]) - SUM(dim_fund[aum_1y_ago_cr]),
    SUM(dim_fund[aum_1y_ago_cr])
)

-- Compounding projection measure (for the "how your money grows" visual)
Projected Value (10Y) =
VAR CAGR = SELECTEDVALUE(fact_fund_scores[hidden_gem_score]) / 100 * 0.18 + 0.08
VAR Years = 10
RETURN 100000 * (1 + CAGR) ^ Years

News Momentum Trend =
CALCULATE(
    AVERAGE(fact_news_sentiment[sentiment_score]),
    DATESINPERIOD(dim_date[date_id], MAX(dim_date[date_id]), -90, DAY)
)

Category Avg Hidden Gem Score =
CALCULATE(
    AVERAGE(fact_fund_scores[hidden_gem_score]),
    ALLEXCEPT(dim_fund, dim_fund[category_id])
)

Rank Within Category =
RANKX(
    FILTER(ALLSELECTED(dim_fund), dim_fund[category_id] = EARLIER(dim_fund[category_id])),
    CALCULATE(AVERAGE(fact_fund_scores[hidden_gem_score]))
)
```

## 4. Pages & visuals (matches `dashboard/index.html`)

### Page 1 — Overview (Groww-style home)
- **Card visuals** (top row): Total AUM, Hidden Gem Count, Avg Hidden Gem Score, Avg Holding Period
- **Line chart**: NAV trend for a slicer-selected fund (X = date, Y = nav) — mirrors the "compounding" chart
- **Bar chart**: Top 10 funds by `hidden_gem_score`, colored by `hidden_gem_flag` (green = flagged)
- **Table/matrix**: Fund list with columns Fund Name | Category | AUM | 3Y CAGR | Hidden Gem Score, conditional-formatted (data bars) on score

### Page 2 — Hidden Gems Explorer
- **Scatter chart**: X = `holding_period_percentile`, Y = `aum_growth_score`, size = `current_aum_cr`, color = `predicted_tier` — this is the signature visual; it visually clusters the "quietly growing, high-conviction" funds in the top-right
- **Slicer**: Category, Risk Grade
- **Card with dynamic text (tooltip page)**: bind to `explanation` column, shown on hover/click — this is the "why is this a hidden gem" panel
- **Small multiples**: sub-score breakdown (holding / news / AUM growth / performance) as 4 mini gauge charts per selected fund

### Page 3 — Fund Deep Dive
- **Line chart**: NAV history with a SIP-style compounding overlay (use the `Projected Value` measure to draw a "what ₹1L becomes" line)
- **KPI visual**: CAGR vs category average
- **News feed table**: `fact_news_sentiment` filtered to selected fund, sorted by date desc

## 5. Theme (match the HTML dashboard exactly)

Import a custom theme JSON (View → Themes → Browse for themes) with:

```json
{
  "name": "HiddenGem",
  "dataColors": ["#2F6B4F", "#1B4332", "#E8B94A", "#8FBC94", "#D4C5A0", "#4A7C59"],
  "background": "#F5F0E1",
  "foreground": "#1B4332",
  "tableAccent": "#E8B94A"
}
```

This gives you: beige page background, dark-green foreground text, green data bars, and yellow (`#E8B94A`) as the single accent for highlights/KPIs — same palette as the HTML preview.

## 6. Publish

Publish to Power BI Service, then embed the report link in your resume/portfolio
site, or export key pages as images for your GitHub README.
