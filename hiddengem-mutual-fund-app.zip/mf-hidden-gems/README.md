# HiddenGem — AI-Powered Mutual Fund Discovery Platform

**Built by Shinoy Babru** — an end-to-end data analytics & ML portfolio project.

Brokerage apps like Groww and Zerodha Coin mostly recommend funds by trailing
star ratings and returns — which means they surface funds the entire market
has *already* found. **HiddenGem** is built around a different question:
which funds are showing the early signals of becoming tomorrow's large-cap
favourite, while they're still under the radar?

It reads three things most platforms ignore or under-weight:

1. **How long investors actually hold the fund** — long average holding
   periods signal real conviction, not hype-driven flows.
2. **How fast money is quietly flowing in**, relative to category peers —
   AUM growth that hasn't shown up in headlines yet.
3. **What financial news is saying**, and whether coverage is accelerating
   from a low base.

These, plus risk-adjusted performance, are blended into a single **Hidden
Gem Score (0–100)**. Funds that score highly *and* haven't yet crossed the
"already-famous large-cap" AUM threshold get flagged, with a plain-English
explanation of exactly why.

**[→ Open the live dashboard preview](dashboard/index.html)**

---

## Why this project exists

Built as a portfolio piece to demonstrate an end-to-end data analytics /
ML workflow: SQL data modeling → Python feature engineering → a scored ML
output → a BI layer (Power BI) → a product-quality front end. Every layer
uses realistic, industry-standard techniques (star schema, Sharpe-style
risk adjustment, percentile ranking within category) so it reads as a real
system, not a toy script.

## Architecture

```
generate_sample_data.py          hidden_gem_model.py              index.html
  (synthetic NAV/AUM/news)  ──▶   (feature engineering +     ──▶   (interactive
  loads star schema into          scoring model, writes             dashboard,
  SQLite per sql/schema.sql)      fact_fund_scores + CSVs)          Power BI
        │                               │                           preview)
        ▼                               ▼
   sql/schema.sql                powerbi/fund_scores_export.csv
   (dim_fund, dim_amc,           (flat table + full star schema
   dim_category, dim_date,        both work for Power BI import —
   fact_nav_history,              see powerbi/POWERBI_GUIDE.md)
   fact_news_sentiment,
   fact_fund_scores)
```

## Repo structure

```
sql/schema.sql                    Star-schema DDL (dims + facts)
data/generate_sample_data.py      Builds SQLite DB + synthetic dataset
ml/hidden_gem_model.py            Feature engineering + Hidden Gem scoring model
news/real_news_ingestion_TEMPLATE.py   Swap-in for live news API + FinBERT sentiment
powerbi/POWERBI_GUIDE.md          Data model, DAX measures, page-by-page build guide
powerbi/fund_scores_export.csv    Model output, ready to import into Power BI
dashboard/index.html              Full interactive dashboard (the resume centerpiece)
docs/enhancement_ideas.md         Roadmap of ways to extend this further
```

## Running it yourself

```bash
pip install -r requirements.txt

cd data
python generate_sample_data.py      # builds hiddengem.db

cd ../ml
python hidden_gem_model.py          # scores funds, writes CSVs for Power BI + dashboard
```

Then open `dashboard/index.html` directly in a browser — the dashboard's
data is embedded inline, so no server is required. (If you regenerate data
and want the dashboard to reflect it without re-embedding, serve the
`dashboard/` folder with `python -m http.server` and switch the two
`<script type="application/json">` blocks to `fetch()` calls against
`data/fund_scores.json` / `data/nav_trends.json` instead.)

For the Power BI report, follow `powerbi/POWERBI_GUIDE.md` — it walks
through data model, every DAX measure, and page layout so your `.pbix`
matches the dashboard preview.

## Design

Color system is a deliberate departure from the blue-accent fintech
default: a beige base (`#F5F0E1`) with a light-to-dark green scale
(`#8FBC94` → `#1B4332`) standing in for the usual "trustworthy blue," and a
single warm yellow (`#E8B94A`) as the accent — used only for the Hidden
Gem badge, the score highlight, and the radar's glow, so it stays legible
as a signal rather than decoration. Fraunces (serif) carries scores and
headlines for a bit of warmth against IBM Plex Sans/Mono's technical,
data-forward body and figures.

The signature piece is the **Hidden Gems Radar** — a quadrant scatter
(holding conviction × AUM momentum, bubble size = AUM) where flagged funds
visibly cluster in the "quiet compounders" corner and pulse with a soft
glow, making the model's thesis visible at a glance before you read a
single number.

The dashboard is fully interactive, not a static mockup:
- **Start SIP** (top nav, and per-row in the table) opens a searchable fund
  picker, which drops you into that fund's detail panel with the SIP
  calculator in view.
- Every fund detail panel includes a **working SIP calculator** (sliders
  for monthly amount, tenure, expected return — prefilled from the model's
  implied CAGR) with live-updating invested / returns / total value and a
  year-by-year growth chart, the same mechanic Groww uses.
- Detail panels also chart **NAV history** and a **fund-vs-category-average
  CAGR comparison** — three charts per fund, not one.
- The Fund Explorer table has **sortable columns** and combined
  search/category/gem-only filtering.

## Data note

All fund names, AMC names, NAV histories, and news items are **synthetic**,
generated by `data/generate_sample_data.py` to exercise the full pipeline
without needing paid market-data or news API keys. AMC names are fictional
but India-anchored (named after Indian rivers, regions and cities — e.g.
"Ganga Mutual Fund", "Deccan Investments") rather than real fund houses,
deliberately avoiding real AMC names (HDFC, SBI, ICICI Prudential, etc.) so
fabricated performance numbers are never attributed to a real, identifiable
company. Categories follow SEBI's standard fund classification (Large Cap,
Mid Cap, Small Cap, Flexi Cap, Sectoral, ELSS, Hybrid), amounts are in ₹
crore, and news sources cited are real Indian financial outlets (Mint,
MoneyControl, ET Markets, Business Standard) used only as source-name
labels on synthetic headlines. Nothing here is real investment data, and
nothing here is investment advice — swap in AMFI/mfapi.in NAV data and a
real news API (see `news/real_news_ingestion_TEMPLATE.py`) before treating
any output as real.

## Tech stack

Python (pandas, scikit-learn) · SQL (star schema, PostgreSQL/SQLite
compatible) · Power BI (DAX) · Vanilla HTML/CSS/JS (no framework — every
chart in the dashboard is hand-built SVG)
