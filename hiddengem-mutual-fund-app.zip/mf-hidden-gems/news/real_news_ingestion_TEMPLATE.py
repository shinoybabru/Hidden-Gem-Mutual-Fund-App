"""
real_news_ingestion_TEMPLATE.py
=================================
Drop-in replacement for the synthetic news generator once you're ready to
go live. This is a TEMPLATE — fill in your API keys and run it in place of
`data/generate_sample_data.py`'s news section.

Recommended free/low-cost sources for a resume/portfolio project:
  - NewsAPI.org           (general financial news search, free tier)
  - GNews.io              (alternative free news API)
  - AMFI India NAVAll.txt (https://www.amfiindia.com/spages/NAVAll.txt) for
                            real daily NAVs — no key required
  - mfapi.in               (free wrapper around AMFI data, JSON, no key)

Pipeline:
  1. Pull fund names from dim_fund
  2. For each fund, query the news API for "<fund name> mutual fund"
  3. Run headlines through a sentiment model (FinBERT or a simple VADER/
     TextBlob pass works fine for a portfolio project — FinBERT is more
     resume-impressive since it's finance-domain-tuned)
  4. Write rows into fact_news_sentiment with the same schema the
     synthetic generator uses, so hidden_gem_model.py needs zero changes
"""

import os
import requests
import sqlite3
from datetime import date

NEWS_API_KEY = os.environ.get("NEWS_API_KEY", "PUT_YOUR_KEY_HERE")
NEWS_API_URL = "https://newsapi.org/v2/everything"

# pip install transformers torch  (for FinBERT)
# from transformers import pipeline
# sentiment_pipeline = pipeline("sentiment-analysis", model="ProsusAI/finbert")


def fetch_headlines(fund_name: str, page_size: int = 10):
    params = {
        "q": f'"{fund_name}" mutual fund',
        "apiKey": NEWS_API_KEY,
        "pageSize": page_size,
        "sortBy": "publishedAt",
        "language": "en",
    }
    resp = requests.get(NEWS_API_URL, params=params, timeout=15)
    resp.raise_for_status()
    return resp.json().get("articles", [])


def score_sentiment(headline: str) -> float:
    """Replace with FinBERT / VADER. Placeholder returns neutral."""
    # result = sentiment_pipeline(headline)[0]
    # sign = 1 if result["label"] == "positive" else -1 if result["label"] == "negative" else 0
    # return sign * result["score"]
    return 0.0


def ingest(conn, fund_id: int, fund_name: str):
    articles = fetch_headlines(fund_name)
    for a in articles:
        score = score_sentiment(a["title"])
        conn.execute(
            "INSERT INTO fact_news_sentiment (fund_id, date_id, headline, source, sentiment_score, mention_count, momentum_flag) "
            "VALUES (?,?,?,?,?,?,?)",
            (fund_id, a["publishedAt"][:10], a["title"], a["source"]["name"], score, 1, False)
        )
    conn.commit()


if __name__ == "__main__":
    conn = sqlite3.connect("../data/hiddengem.db")
    funds = conn.execute("SELECT fund_id, fund_name FROM dim_fund").fetchall()
    for fund_id, fund_name in funds:
        try:
            ingest(conn, fund_id, fund_name)
        except Exception as e:
            print(f"Skipped {fund_name}: {e}")
