-- ============================================================
-- HiddenGem — AI-Powered Mutual Fund Discovery Platform
-- Database Schema (PostgreSQL / SQLite compatible)
-- ============================================================
-- Design note: built as a star schema so it drops straight into
-- Power BI (fact table + dimension tables) with no remodeling.
-- ============================================================

DROP TABLE IF EXISTS fact_nav_history;
DROP TABLE IF EXISTS fact_news_sentiment;
DROP TABLE IF EXISTS fact_fund_scores;
DROP TABLE IF EXISTS dim_fund;
DROP TABLE IF EXISTS dim_category;
DROP TABLE IF EXISTS dim_date;
DROP TABLE IF EXISTS dim_amc;

-- ---------------------------------------------------
-- DIMENSION: Asset Management Company
-- ---------------------------------------------------
CREATE TABLE dim_amc (
    amc_id          INTEGER PRIMARY KEY,
    amc_name        TEXT NOT NULL,
    founded_year    INTEGER,
    aum_cr          NUMERIC(14,2)          -- total AMC AUM in ₹ crore
);

-- ---------------------------------------------------
-- DIMENSION: Fund category (Large-cap, Mid-cap, Flexi-cap, Small-cap, Sectoral...)
-- ---------------------------------------------------
CREATE TABLE dim_category (
    category_id     INTEGER PRIMARY KEY,
    category_name   TEXT NOT NULL,
    risk_grade      TEXT CHECK (risk_grade IN ('Low','Moderate','High','Very High'))
);

-- ---------------------------------------------------
-- DIMENSION: Calendar (standard Power BI date table)
-- ---------------------------------------------------
CREATE TABLE dim_date (
    date_id         DATE PRIMARY KEY,
    year            INTEGER,
    quarter         INTEGER,
    month           INTEGER,
    month_name      TEXT,
    day             INTEGER,
    week_of_year    INTEGER,
    is_month_end    BOOLEAN
);

-- ---------------------------------------------------
-- DIMENSION: Fund master
-- ---------------------------------------------------
CREATE TABLE dim_fund (
    fund_id             INTEGER PRIMARY KEY,
    fund_name           TEXT NOT NULL,
    amc_id              INTEGER REFERENCES dim_amc(amc_id),
    category_id         INTEGER REFERENCES dim_category(category_id),
    inception_date      DATE,
    expense_ratio_pct   NUMERIC(5,2),
    fund_manager        TEXT,
    is_direct_plan      BOOLEAN DEFAULT TRUE,
    current_aum_cr      NUMERIC(14,2),          -- current AUM, ₹ crore
    aum_1y_ago_cr       NUMERIC(14,2),          -- AUM a year ago -> growth rate
    avg_holding_period_months NUMERIC(6,2),     -- investor behaviour signal
    holding_period_percentile NUMERIC(5,2),     -- percentile vs category peers (0-100)
    exit_load_pct       NUMERIC(5,2)
);

-- ---------------------------------------------------
-- FACT: Daily NAV history (for return & compounding calculations)
-- ---------------------------------------------------
CREATE TABLE fact_nav_history (
    nav_id          BIGINT PRIMARY KEY,
    fund_id         INTEGER REFERENCES dim_fund(fund_id),
    date_id         DATE REFERENCES dim_date(date_id),
    nav             NUMERIC(10,4) NOT NULL
);

-- ---------------------------------------------------
-- FACT: News sentiment / mention signals per fund per day
-- (This is the "read the news to find hidden gems" engine's raw feed)
-- ---------------------------------------------------
CREATE TABLE fact_news_sentiment (
    news_id             BIGINT PRIMARY KEY,
    fund_id             INTEGER REFERENCES dim_fund(fund_id),
    date_id             DATE REFERENCES dim_date(date_id),
    headline            TEXT,
    source              TEXT,
    sentiment_score      NUMERIC(4,3),     -- -1 (very negative) to +1 (very positive)
    mention_count        INTEGER,          -- number of articles that day
    momentum_flag        BOOLEAN           -- true if mentions are accelerating
);

-- ---------------------------------------------------
-- FACT: Model output — the "Hidden Gem Score" per fund per month
-- This is what the ML model in /ml writes back to.
-- ---------------------------------------------------
CREATE TABLE fact_fund_scores (
    score_id                BIGINT PRIMARY KEY,
    fund_id                 INTEGER REFERENCES dim_fund(fund_id),
    date_id                 DATE REFERENCES dim_date(date_id),
    holding_strength_score  NUMERIC(5,2),   -- 0-100, from investor holding behaviour
    news_momentum_score     NUMERIC(5,2),   -- 0-100, from news/sentiment trend
    aum_growth_score        NUMERIC(5,2),   -- 0-100, from AUM growth rate vs category
    performance_score       NUMERIC(5,2),   -- 0-100, from risk-adjusted returns
    hidden_gem_score        NUMERIC(5,2),   -- 0-100, final blended model output
    hidden_gem_flag         BOOLEAN,        -- true if score crosses threshold & fund is NOT already large-cap-famous
    predicted_tier          TEXT,           -- 'Emerging Large-Cap', 'Emerging Flexi-Cap', etc.
    explanation             TEXT            -- human-readable reason, shown in the "why is this a hidden gem" panel
);

CREATE INDEX idx_nav_fund_date ON fact_nav_history(fund_id, date_id);
CREATE INDEX idx_news_fund_date ON fact_news_sentiment(fund_id, date_id);
CREATE INDEX idx_score_fund_date ON fact_fund_scores(fund_id, date_id);
