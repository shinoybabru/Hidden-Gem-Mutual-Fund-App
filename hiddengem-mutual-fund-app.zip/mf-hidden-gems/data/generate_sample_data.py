"""
generate_sample_data.py
========================
Generates a realistic SYNTHETIC dataset for the HiddenGem project and loads
it into a local SQLite database (hiddengem.db) that matches sql/schema.sql.

Why synthetic data? Real NAV/AMFI data and live news feeds require external
APIs (AMFI NAVAll.txt, mfapi.in, NewsAPI, etc.) that aren't reachable from
this environment. The generator below mimics realistic distributions
(AUM, expense ratios, holding periods, NAV compounding, news sentiment) so
the ML model, SQL, and dashboard all work end-to-end on day one. Swap this
out for the real ingestion script in `data/real_ingestion_TEMPLATE.py`
when you deploy with live API keys.

Run:
    python generate_sample_data.py
"""

import sqlite3
import random
import math
from datetime import date, timedelta

random.seed(42)

DB_PATH = "hiddengem.db"

# NOTE ON NAMING: these AMC names are fictional but India-anchored (named
# after Indian rivers, regions, and cities) rather than real fund houses.
# We deliberately avoid real AMC names (HDFC, SBI, ICICI Prudential, etc.)
# because pairing them with fabricated NAV/AUM/return numbers would risk
# misattributing synthetic performance data to real, identifiable
# companies. Swap in real AMCs only once this is wired to real AMFI/NSE
# data (see news/real_news_ingestion_TEMPLATE.py for the live-data path).
AMCS = [
    ("Ganga Mutual Fund", 2005, 185000),
    ("Konkan Asset Management", 1998, 412000),
    ("Deccan Investments", 2011, 76000),
    ("Malabar Capital", 1994, 298000),
    ("Vindhya Asset Mgmt", 2016, 34000),
    ("Coromandel Mutual Fund", 2001, 156000),
    ("Nilgiri Growth AMC", 2009, 92000),
    ("Yamuna Wealth", 2013, 51000),
    ("Sahyadri Mutual Fund", 1999, 224000),
    ("Brahmaputra Capital", 2007, 61000),
]

CATEGORIES = [
    ("Large Cap", "Moderate"),
    ("Mid Cap", "High"),
    ("Small Cap", "Very High"),
    ("Flexi Cap", "High"),
    ("Sectoral - Technology", "Very High"),
    ("Sectoral - Banking", "High"),
    ("ELSS (Tax Saver)", "High"),
    ("Hybrid - Aggressive", "Moderate"),
]

# Benchmark index each category is typically compared against on Indian platforms
CATEGORY_BENCHMARKS = {
    "Large Cap": "Nifty 100 TRI",
    "Mid Cap": "Nifty Midcap 150 TRI",
    "Small Cap": "Nifty Smallcap 250 TRI",
    "Flexi Cap": "Nifty 500 TRI",
    "Sectoral - Technology": "Nifty IT TRI",
    "Sectoral - Banking": "Nifty Bank TRI",
    "ELSS (Tax Saver)": "Nifty 500 TRI",
    "Hybrid - Aggressive": "CRISIL Hybrid 35+65 Aggressive Index",
}

FUND_NAME_STEMS = [
    "Rising Bharat", "Emerging Opportunities", "Growth Pioneer", "Value Discovery",
    "Focused Equity", "Navratna", "Momentum Edge", "Wealth Builder", "Prime Growth",
    "Future Titans", "Alpha Generator", "Compounder", "Frontier Equity", "Swaraj Growth",
    "Horizon Equity", "Steady Climb", "Next Gen Equity", "Vantage Point", "Udaan Equity",
    "Ascent Equity", "Trailblazer", "Shikhar Growth", "Evergreen Equity", "Quantum Leap",
    "Nova Growth", "Sunrise Equity", "Cornerstone", "Milestone Equity", "Sankalp Growth",
    "Beacon Equity",
]

INDIAN_MANAGER_FIRST = ["Rohan", "Ananya", "Vikram", "Priya", "Arjun", "Kavita", "Rajesh",
                         "Sneha", "Karthik", "Meera", "Aditya", "Nisha", "Suresh", "Divya"]
INDIAN_MANAGER_LAST = ["Rao", "Iyer", "Mehta", "Nair", "Kapoor", "Deshmukh", "Reddy",
                        "Kulkarni", "Chatterjee", "Bhatia", "Menon", "Agarwal", "Pillai", "Joshi"]

NEWS_TEMPLATES_POS = [
    "{fund} sees strong SIP inflows as investors stay invested longer",
    "Fund managers flag {fund} among top consistent performers this quarter",
    "{fund} AUM grows steadily amid rising retail participation",
    "Analysts note {fund}'s low churn as a sign of investor confidence",
    "{fund} quietly outperforms category average over 3-year rolling returns",
    "Institutional interest picks up in {fund} ahead of index rebalancing",
]
NEWS_TEMPLATES_NEG = [
    "{fund} sees mild redemption pressure amid sector rotation",
    "{fund} underperforms benchmark in volatile quarter",
    "Rising expense ratio draws scrutiny for {fund}",
]

def daterange(start, end):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)

def build_dim_date(conn, start, end):
    rows = []
    for d in daterange(start, end):
        rows.append((
            d.isoformat(), d.year, (d.month - 1) // 3 + 1, d.month,
            d.strftime("%B"), d.day, d.isocalendar()[1],
            (d + timedelta(days=1)).month != d.month
        ))
    conn.executemany(
        "INSERT INTO dim_date VALUES (?,?,?,?,?,?,?,?)", rows
    )

def main():
    conn = sqlite3.connect(DB_PATH)
    with open("../sql/schema.sql") as f:
        conn.executescript(f.read())

    # ---- Calendar: 3 years of daily dates ----
    start_date = date(2023, 7, 1)
    end_date = date(2026, 6, 30)
    build_dim_date(conn, start_date, end_date)

    # ---- AMCs ----
    for i, (name, founded, aum) in enumerate(AMCS, start=1):
        conn.execute("INSERT INTO dim_amc VALUES (?,?,?,?)", (i, name, founded, aum))

    # ---- Categories ----
    for i, (name, risk) in enumerate(CATEGORIES, start=1):
        conn.execute("INSERT INTO dim_category VALUES (?,?,?)", (i, name, risk))

    # ---- Funds ----
    fund_id = 1
    funds = []
    for stem in FUND_NAME_STEMS:
        amc_id = random.randint(1, len(AMCS))
        category_id = random.randint(1, len(CATEGORIES))
        amc_name = AMCS[amc_id - 1][0].split()[0]
        fund_name = f"{amc_name} {stem} Fund"
        inception = date(random.randint(2010, 2022), random.randint(1, 12), 1)
        expense_ratio = round(random.uniform(0.45, 2.1), 2)
        current_aum = round(random.uniform(150, 45000), 1)
        # Some funds intentionally get a "quietly growing" profile — these are
        # the ones the model should surface as hidden gems.
        is_stealth_grower = random.random() < 0.3
        if is_stealth_grower:
            aum_growth_rate = random.uniform(0.55, 1.4)   # 55%-140% YoY AUM growth
            avg_holding = random.uniform(30, 54)          # long holding period = sticky investors
        else:
            aum_growth_rate = random.uniform(-0.1, 0.45)
            avg_holding = random.uniform(6, 28)
        aum_1y_ago = round(current_aum / (1 + aum_growth_rate), 1)
        holding_percentile = min(99, max(1, avg_holding / 54 * 100 + random.uniform(-8, 8)))
        exit_load = round(random.choice([0, 0.25, 0.5, 1.0]), 2)

        funds.append(dict(
            fund_id=fund_id, fund_name=fund_name, amc_id=amc_id, category_id=category_id,
            inception=inception, expense_ratio=expense_ratio, current_aum=current_aum,
            aum_1y_ago=aum_1y_ago, avg_holding=avg_holding, holding_percentile=holding_percentile,
            exit_load=exit_load, is_stealth_grower=is_stealth_grower
        ))

        manager_name = f"{random.choice(INDIAN_MANAGER_FIRST)} {random.choice(INDIAN_MANAGER_LAST)}"
        conn.execute(
            "INSERT INTO dim_fund VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (fund_id, fund_name, amc_id, category_id, inception.isoformat(), expense_ratio,
             manager_name,
             True, current_aum, aum_1y_ago, round(avg_holding, 1), round(holding_percentile, 1), exit_load)
        )
        fund_id += 1

    # ---- NAV history (simulate geometric brownian motion w/ drift tied to fund quality) ----
    nav_id = 1
    news_id = 1
    total_days = (end_date - start_date).days
    for f in funds:
        base_nav = random.uniform(18, 120)
        nav = base_nav
        # stealth growers get a slightly higher, steadier drift
        annual_drift = random.uniform(0.14, 0.24) if f["is_stealth_grower"] else random.uniform(0.06, 0.16)
        daily_drift = annual_drift / 252
        daily_vol = random.uniform(0.008, 0.016)
        d = start_date
        day_count = 0
        while d <= end_date:
            if d.weekday() < 5:  # market days only
                shock = random.gauss(0, daily_vol)
                nav = max(1, nav * (1 + daily_drift + shock))
                conn.execute(
                    "INSERT INTO fact_nav_history VALUES (?,?,?,?)",
                    (nav_id, f["fund_id"], d.isoformat(), round(nav, 4))
                )
                nav_id += 1

                # sparse news events, more frequent + more positive for stealth growers
                news_chance = 0.012 if f["is_stealth_grower"] else 0.004
                if random.random() < news_chance:
                    positive = random.random() < (0.78 if f["is_stealth_grower"] else 0.5)
                    template = random.choice(NEWS_TEMPLATES_POS if positive else NEWS_TEMPLATES_NEG)
                    conn.execute(
                        "INSERT INTO fact_news_sentiment VALUES (?,?,?,?,?,?,?,?)",
                        (news_id, f["fund_id"], d.isoformat(),
                         template.format(fund=f["fund_name"]), random.choice(["Mint", "MoneyControl", "ET Markets", "Business Standard"]),
                         round(random.uniform(0.3, 0.9) if positive else random.uniform(-0.7, -0.1), 3),
                         random.randint(1, 6),
                         f["is_stealth_grower"] and random.random() < 0.4)
                    )
                    news_id += 1
            d += timedelta(days=1)
            day_count += 1

    conn.commit()
    conn.close()
    print(f"Done. {fund_id - 1} funds, {nav_id - 1} NAV rows, {news_id - 1} news rows written to {DB_PATH}")

if __name__ == "__main__":
    main()
