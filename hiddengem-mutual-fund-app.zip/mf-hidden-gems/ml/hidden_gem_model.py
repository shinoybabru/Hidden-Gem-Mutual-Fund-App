"""
hidden_gem_model.py
=====================
Core intelligence of HiddenGem.

Most brokerage apps (Groww, Zerodha Coin, etc.) rank/recommend funds mainly
by trailing returns and star ratings — which means they mostly surface funds
that are ALREADY large and already popular. This model instead looks for
funds that show the *early signals* of becoming tomorrow's large-cap
favourite, while they're still under the radar:

    1. Holding Strength   -> are existing investors staying invested for
                              long periods (a proxy for genuine conviction,
                              not hype-driven flows)?
    2. News Momentum      -> is coverage/sentiment about the fund
                              accelerating, even from a low base?
    3. AUM Growth         -> is money quietly flowing in faster than the
                              fund's category peers?
    4. Risk-Adjusted Perf -> is the fund compounding well per unit of risk
                              (Sharpe-style), not just posting a lucky return?

These four sub-scores (0-100 each) are blended into a single
`hidden_gem_score`. A fund is flagged `hidden_gem_flag = True` only if:
  - hidden_gem_score >= 70, AND
  - current_aum_cr is still below the "already-famous large-cap" threshold
    (i.e. it hasn't been fully discovered by the market yet)

This keeps the definition honest: a fund that's already a ₹50,000cr
large-cap giant doesn't need to be "discovered."

Usage:
    python hidden_gem_model.py
Requires: pandas, numpy, scikit-learn (pip install -r ../requirements.txt)
"""

import sqlite3
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor

DB_PATH = "../data/hiddengem.db"
ALREADY_FAMOUS_AUM_THRESHOLD_CR = 20000  # above this, a fund is "already discovered"


def load_data(conn):
    funds = pd.read_sql("SELECT * FROM dim_fund", conn)
    nav = pd.read_sql("SELECT * FROM fact_nav_history", conn, parse_dates=["date_id"])
    news = pd.read_sql("SELECT * FROM fact_news_sentiment", conn, parse_dates=["date_id"])
    categories = pd.read_sql("SELECT * FROM dim_category", conn)
    amcs = pd.read_sql("SELECT * FROM dim_amc", conn)
    return funds, nav, news, categories, amcs


def compute_returns_and_risk(nav_df):
    """Per-fund CAGR and volatility from NAV history (used for performance_score)."""
    out = []
    for fund_id, g in nav_df.sort_values("date_id").groupby("fund_id"):
        g = g.reset_index(drop=True)
        if len(g) < 30:
            continue
        first_nav, last_nav = g["nav"].iloc[0], g["nav"].iloc[-1]
        years = (g["date_id"].iloc[-1] - g["date_id"].iloc[0]).days / 365.25
        cagr = (last_nav / first_nav) ** (1 / max(years, 0.1)) - 1
        daily_returns = g["nav"].pct_change().dropna()
        vol = daily_returns.std() * np.sqrt(252)
        sharpe_like = cagr / vol if vol > 0 else 0
        out.append(dict(fund_id=fund_id, cagr=cagr, volatility=vol, sharpe_like=sharpe_like))
    return pd.DataFrame(out)


def compute_news_momentum(news_df):
    """Recent (last 90d) sentiment & mention volume vs prior 90d -> momentum."""
    if news_df.empty:
        return pd.DataFrame(columns=["fund_id", "news_momentum_raw"])
    max_date = news_df["date_id"].max()
    recent = news_df[news_df["date_id"] > max_date - pd.Timedelta(days=90)]
    prior = news_df[(news_df["date_id"] <= max_date - pd.Timedelta(days=90)) &
                     (news_df["date_id"] > max_date - pd.Timedelta(days=180))]

    def agg(df):
        return df.groupby("fund_id").agg(
            mentions=("mention_count", "sum"),
            avg_sentiment=("sentiment_score", "mean")
        )

    r, p = agg(recent), agg(prior)
    joined = r.join(p, how="left", rsuffix="_prior").fillna(0)
    joined["mention_growth"] = (joined["mentions"] - joined["mentions_prior"]) / (joined["mentions_prior"] + 1)
    joined["news_momentum_raw"] = joined["avg_sentiment"].fillna(0) * 0.5 + \
                                   np.tanh(joined["mention_growth"]) * 0.5
    return joined.reset_index()[["fund_id", "news_momentum_raw"]]


def build_feature_table(funds, nav, news, categories, amcs):
    perf = compute_returns_and_risk(nav)
    momentum = compute_news_momentum(news)

    df = funds.merge(perf, on="fund_id", how="left") \
               .merge(momentum, on="fund_id", how="left") \
               .merge(categories, on="category_id", how="left") \
               .merge(amcs[["amc_id", "amc_name"]], on="amc_id", how="left")

    df["news_momentum_raw"] = df["news_momentum_raw"].fillna(0)
    df["aum_growth_rate"] = (df["current_aum_cr"] - df["aum_1y_ago_cr"]) / df["aum_1y_ago_cr"].replace(0, np.nan)
    df["aum_growth_rate"] = df["aum_growth_rate"].fillna(0)

    # rank AUM growth against category peers (so a mid-cap fund isn't judged
    # against large-cap growth norms, etc.)
    df["aum_growth_vs_category"] = df.groupby("category_id")["aum_growth_rate"].rank(pct=True)

    return df


def scale_0_100(series):
    s = series.replace([np.inf, -np.inf], np.nan).fillna(series.median())
    scaler = MinMaxScaler(feature_range=(0, 100))
    return scaler.fit_transform(s.values.reshape(-1, 1)).flatten()


def score_funds(df):
    df = df.copy()
    df["holding_strength_score"] = scale_0_100(df["holding_period_percentile"])
    df["news_momentum_score"] = scale_0_100(df["news_momentum_raw"])
    df["aum_growth_score"] = scale_0_100(df["aum_growth_vs_category"])
    df["performance_score"] = scale_0_100(df["sharpe_like"].fillna(0))

    # Blend weights: holding strength & AUM growth (real conviction signals)
    # are weighted more heavily than raw news buzz, by design — news alone
    # is noisy and easy to game.
    weights = dict(holding=0.32, aum=0.28, perf=0.25, news=0.15)
    df["hidden_gem_score"] = (
        df["holding_strength_score"] * weights["holding"] +
        df["aum_growth_score"] * weights["aum"] +
        df["performance_score"] * weights["perf"] +
        df["news_momentum_score"] * weights["news"]
    ).round(1)

    df["hidden_gem_flag"] = (df["hidden_gem_score"] >= 70) & (df["current_aum_cr"] < ALREADY_FAMOUS_AUM_THRESHOLD_CR)

    def predicted_tier(row):
        if not row["hidden_gem_flag"]:
            return "Established / Not Flagged"
        cat = row["category_name"]
        if "Small" in cat:
            return "Emerging Mid-Cap"
        if "Mid" in cat:
            return "Emerging Large-Cap"
        if "Flexi" in cat:
            return "Emerging Large-Cap Flexi"
        if "Sectoral" in cat:
            return "Emerging Flexi-Cap (post-diversification)"
        return "Emerging Large-Cap"

    df["predicted_tier"] = df.apply(predicted_tier, axis=1)

    def explain(row):
        reasons = []
        if row["holding_strength_score"] > 65:
            reasons.append(f"investors hold this fund {row['avg_holding_period_months']:.0f} months on average "
                            f"({row['holding_period_percentile']:.0f}th percentile in its category) — a sign of real conviction, not hype")
        if row["aum_growth_score"] > 65:
            growth_pct = row["aum_growth_rate"] * 100
            reasons.append(f"AUM has grown {growth_pct:.0f}% YoY, outpacing most {row['category_name']} peers")
        if row["performance_score"] > 65:
            reasons.append(f"delivering a {row['cagr']*100:.1f}% CAGR at controlled volatility (risk-adjusted, not a lucky spike)")
        if row["news_momentum_score"] > 65:
            reasons.append("analyst and media mentions are accelerating from a low base — still early")
        if not reasons:
            reasons.append("solid fundamentals but no single standout signal yet")
        return "This fund is still under the radar because " + "; and ".join(reasons) + "."

    df["explanation"] = df.apply(explain, axis=1)
    return df


def write_back(conn, scored_df, as_of_date):
    conn.execute("DELETE FROM fact_fund_scores WHERE date_id = ?", (as_of_date,))
    rows = []
    for i, row in scored_df.iterrows():
        rows.append((
            i + 1, int(row["fund_id"]), as_of_date,
            float(row["holding_strength_score"]), float(row["news_momentum_score"]),
            float(row["aum_growth_score"]), float(row["performance_score"]),
            float(row["hidden_gem_score"]), bool(row["hidden_gem_flag"]),
            row["predicted_tier"], row["explanation"]
        ))
    conn.executemany(
        "INSERT INTO fact_fund_scores VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows
    )
    conn.commit()


def main():
    conn = sqlite3.connect(DB_PATH)
    funds, nav, news, categories, amcs = load_data(conn)
    feats = build_feature_table(funds, nav, news, categories, amcs)
    scored = score_funds(feats)

    as_of = str(nav["date_id"].max().date())
    write_back(conn, scored, as_of)

    # Exports for Power BI (flat, denormalized — easiest to build visuals on)
    export_cols = [
        "fund_id", "fund_name", "amc_name", "fund_manager", "category_name", "risk_grade", "current_aum_cr",
        "aum_growth_rate", "avg_holding_period_months", "holding_period_percentile",
        "cagr", "volatility", "sharpe_like", "holding_strength_score",
        "aum_growth_score", "performance_score", "news_momentum_score",
        "hidden_gem_score", "hidden_gem_flag", "predicted_tier", "explanation", "expense_ratio_pct"
    ]
    scored[export_cols].sort_values("hidden_gem_score", ascending=False) \
        .to_csv("../powerbi/fund_scores_export.csv", index=False)

    # Trimmed feed for the HTML dashboard (top all-round funds + top hidden gems)
    scored[export_cols].sort_values("hidden_gem_score", ascending=False) \
        .to_csv("../dashboard/data/fund_scores.csv", index=False)

    top_gems = scored[scored["hidden_gem_flag"]].sort_values("hidden_gem_score", ascending=False)
    print(f"Scored {len(scored)} funds. {len(top_gems)} flagged as Hidden Gems.")
    print(top_gems[["fund_name", "category_name", "hidden_gem_score", "predicted_tier"]].head(10).to_string(index=False))


if __name__ == "__main__":
    main()
